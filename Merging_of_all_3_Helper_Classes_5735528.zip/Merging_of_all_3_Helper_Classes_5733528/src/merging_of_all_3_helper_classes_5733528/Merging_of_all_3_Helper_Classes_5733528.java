 /*
 * @author          5735528
 * Title:           Merging_of_all_3_Helper_Classes_5733528
 * Semester:        COP3804 - Spring 2019
 * Lecturer's Name: Cristy Charters
 * Description of Program's Functionality: 
 * This program is the driver/tester class of Merging_of_all_3_Helper_Classes_5733528. 
 * It's purpose is to perform the logic of a fellow classmate based on the three programs he's done. 
 * Those programs will be put into their own helper classes, 
 * and be called forth based on the option that the user inputs from the main method. 
 */

package merging_of_all_3_helper_classes_5733528; //Name of the package

import java.util.InputMismatchException; //Imported InputMismatchException class to handle exception of this type
import java.util.Scanner; //Imported Scanner class to receive input from the user

/**
 *
 * @author TheArcade36 Dell G3
 */

//The whole public Merging_of_all_3_Helper_Classes_5733528 class is contained within here: 
public class Merging_of_all_3_Helper_Classes_5733528 {

    /**
     * @param args the command line arguments
     */
    
    //Displays the menu to the user
    public void showMenu() {
        System.out.print("\n1. Palindrome Tester"
                + "\n2. Reverse Poem"
                + "\n3. Adopt-A-Pet"
                + "\n4. exit\n");
    }
    
    /* Main method is where the program executes chronologically from top-down. 
     * Instantiates Merging_of_all_3_Helper_Classes_5733528, PalindromeHelper, ReversePoemHelper, AdoptAPetHelper classes. 
     * Displays the user a menu of options, 
     * the user will input a choice which will handle InputMismatchExceptions, 
     * and keeps looping if the user doesn't input 4 to exit. 
     * Based on the user's option, 
     * then it'll call the appropriate method within the switch statement from the helper class they're from. 
     */
    public static void main(String[] args) {
        Merging_of_all_3_Helper_Classes_5733528 central = new Merging_of_all_3_Helper_Classes_5733528();
        PalindromeHelper myPalindrome = new PalindromeHelper();
        ReversePoemHelper myReversePoem = new ReversePoemHelper();
        AdoptAPetHelper myAdoptAPet = new AdoptAPetHelper();
        ////////////////////////////////////////////////////////////////////////
        int userChoice = 0;
        boolean loopAgain = true;
        Scanner keyboard = new Scanner(System.in);
        while (loopAgain)
        {
            try
            {
                do
                {
                    central.showMenu();
                    userChoice = keyboard.nextInt();
                    keyboard.nextLine();
                    loopAgain = false;
                    
                    ////////////////////////////////////////////////////////////////////////
                    switch(userChoice)
                    {
                        case 1: 
                            myPalindrome.isPalindrome();
                            break;
                        case 2: 
                            myReversePoem.readFileLoadStack();
                            break;
                        case 3: 
                            myAdoptAPet.displayMenu();
                            //Not quite familiar with GUIs, but the logic would work if otherwise. 
                            break;
                        default: 
                            break;
                    }
                    ////////////////////////////////////////////////////////////////////////
                }while(userChoice != 4);
            }
            catch(InputMismatchException e)
            {
                keyboard.nextLine();
                loopAgain = true;
                System.out.println("Please enter an integer between one through four.");
            }
        }
    }
}
