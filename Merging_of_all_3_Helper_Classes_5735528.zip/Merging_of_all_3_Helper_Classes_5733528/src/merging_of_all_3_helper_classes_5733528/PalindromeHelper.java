/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package merging_of_all_3_helper_classes_5733528;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author TheArcade36 Dell G3
 */

public class PalindromeHelper {
    /**
     *
     * Title:           Linked List of a Palindrome
     * Semester:        COP3804 – Spring 2019
     *
     * @author 6114243(Do NOT Use Your First or Last Name) Instructor: C. Charters
     *
     * Due Date: 04/12/19
     *
     * Introduction to linked lists, reversing linked lists, and comparing objects.
     */


    /**
     *
     * @author mtsguest
     */

    /**
     * @param args the command line arguments
     */
    public void isPalindrome() {
        File myFile;
        Scanner inFile = null;
        String word;
        LinkedList<String> possiblePal;
        HelperPal myPalHelp = new HelperPal();

        try {
            myFile = new File("candidates.txt");
            inFile = new Scanner(myFile);
            while (inFile.hasNext()) {
                word = inFile.next();
                possiblePal = makeLinkedList(word);

                if (myPalHelp.isPalindrome(possiblePal)) {
                    System.out.println(word + " is a Palindrome.");

                } else {
                    System.out.println(word + " is NOT a Palindrome.");
                }

            }

        } catch (IOException e) {
            System.out.println("Sorry, wrong file.  Come back later.");
        } finally {
            if (inFile != null) {
                inFile.close();
            }
        }
    }
    
    public LinkedList<String> makeLinkedList(String word) {
        LinkedList<String> list = new LinkedList<>();
        String[] arr = word.split("");
        for(String s : arr){
            list.addLast(s);
        }
    return list;
    }
    
    ////////////////////////////////////////////////////////////////////////////
    
    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */

    /**
     *
     * @author mtsguest
     */
    public class HelperPal {
        /**
         * Basically initiates the process of checking if palindrome.
         * Called from driver class.
         * @param llist linked list.
         * @return true if linked list is a palindrome.
         */
        public boolean isPalindrome(LinkedList<String> llist) {
            return newReversedLinkedList(llist).equals(llist);
        }
        /**
         * Creates a new reversed linked list from a give on one.
         * @param input linked list.
         * @return new reversed linked list from the original
         */
        public LinkedList<String> newReversedLinkedList(LinkedList<String> input) {
            LinkedList<String> list = new LinkedList<>();
            Iterator lit = input.descendingIterator();

            while (lit.hasNext()) {
                list.addLast(lit.next().toString());
            }
            return list;
        }
        /**
         * Check if two linked lists are equal.
         * @param llist1 linked list 1
         * @param llist2 linked list 2
         * @return true if the lists are equal.
         */
        public boolean isEqual(LinkedList<String> llist1, LinkedList<String> llist2) {
            return llist1.equals(llist2);
        }
    }
}


    
    

